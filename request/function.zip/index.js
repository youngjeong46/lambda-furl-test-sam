var https = require('https');

function getRequest() {
  const url = process.env.FUNCTION_URL;

  return new Promise((resolve, reject) => {
    const req = https.get(url, res => {
      let rawData = '';

      res.on('data', chunk => {
        rawData += chunk;
      });

      res.on('end', () => {
        try {
          resolve(JSON.parse(rawData));
        } catch (err) {
          reject(new Error(err));
        }
      });
    });

    req.on('error', err => {
      reject(new Error(err));
    });
  });
}

exports.handler = async (event) => {
    try {
        const result = await getRequest();

        return {
            statusCode: 200,
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify(result),
        };
    } catch (error) {
        console.log('Error is: ', error);
        return {
            statusCode: 400,
            body: error.message,
        };
    }
};
